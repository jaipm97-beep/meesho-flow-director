document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const form = document.getElementById("scriptForm");
  const creatorInput = document.getElementById("creatorInput");
  const creatorPrompt = document.getElementById("creatorPrompt");
  const creatorPreviewBox = document.getElementById("creatorPreviewBox");
  const creatorPreviewImg = document.getElementById("creatorPreviewImg");
  const removeCreatorBtn = document.getElementById("removeCreatorBtn");

  const productInput = document.getElementById("productInput");
  const productPrompt = document.getElementById("productPrompt");
  const productPreviewGrid = document.getElementById("productPreviewGrid");

  const durationGroup = document.getElementById("durationGroup");
  const languageGroup = document.getElementById("languageGroup");
  const presentationGroup = document.getElementById("presentationGroup");
  const categoryHint = document.getElementById("categoryHint");
  const productNotes = document.getElementById("productNotes");
  const demoModeToggle = document.getElementById("demoModeToggle");
  const generateBtn = document.getElementById("generateBtn");

  const emptyState = document.getElementById("emptyState");
  const loadingState = document.getElementById("loadingState");
  const resultContainer = document.getElementById("resultContainer");
  const outputActions = document.getElementById("outputActions");
  const interactiveOutput = document.getElementById("interactiveOutput");
  const rawMarkdownCode = document.getElementById("rawMarkdownCode");

  const copyAllBtn = document.getElementById("copyAllBtn");
  const downloadBtn = document.getElementById("downloadBtn");
  const toast = document.getElementById("toast");

  // Safe Crop Preview Elements
  const safeCropCard = document.getElementById("safeCropCard");
  const safeCropGallery = document.getElementById("safeCropGallery");

  // API Key Modal Elements
  const apiKeyBtn = document.getElementById("apiKeyBtn");
  const keyModal = document.getElementById("keyModal");
  const closeKeyModal = document.getElementById("closeKeyModal");
  const cancelKeyModal = document.getElementById("cancelKeyModal");
  const saveKeyBtn = document.getElementById("saveKeyBtn");
  const modalKeyInput = document.getElementById("modalKeyInput");
  const keyIndicator = document.getElementById("keyIndicator");
  const keyBtnLabel = document.getElementById("keyBtnLabel");

  // State
  let creatorFile = null;
  let productFiles = [];
  let selectedDuration = "30 seconds";
  let selectedLanguage = "Hinglish";
  let selectedPresentation = "Magic Transition";
  let currentMarkdown = "";

  // Check initial API Key status
  fetchStatus();

  function fetchStatus() {
    fetch("/api/status")
      .then(res => res.json())
      .then(data => {
        if (data.has_api_key) {
          keyIndicator.classList.add("active");
          keyBtnLabel.textContent = `API Key: ${data.masked_key}`;
        } else {
          keyIndicator.classList.remove("active");
          keyBtnLabel.textContent = "Set API Key";
        }
      })
      .catch(() => {});
  }

  // --- Pill Groups Selection ---
  const customDurationWrapper = document.getElementById("customDurationWrapper");
  const customDurRange = document.getElementById("customDurRange");
  const customDurVal = document.getElementById("customDurVal");

  durationGroup.querySelectorAll(".pill").forEach(pill => {
    pill.addEventListener("click", () => {
      durationGroup.querySelectorAll(".pill").forEach(p => p.classList.remove("active"));
      pill.classList.add("active");
      if (pill.dataset.val === "custom") {
        if (customDurationWrapper) customDurationWrapper.style.display = "block";
        selectedDuration = customDurRange ? customDurRange.value + " seconds" : "25 seconds";
      } else {
        if (customDurationWrapper) customDurationWrapper.style.display = "none";
        selectedDuration = pill.dataset.val;
      }
    });
  });

  if (customDurRange && customDurVal) {
    customDurRange.addEventListener("input", (e) => {
      const val = e.target.value;
      customDurVal.innerText = val + " seconds";
      selectedDuration = val + " seconds";
    });
  }

  languageGroup.querySelectorAll(".pill").forEach(pill => {
    pill.addEventListener("click", () => {
      languageGroup.querySelectorAll(".pill").forEach(p => p.classList.remove("active"));
      pill.classList.add("active");
      selectedLanguage = pill.dataset.val;
    });
  });

  if (presentationGroup) {
    presentationGroup.querySelectorAll(".pill").forEach(pill => {
      pill.addEventListener("click", () => {
        presentationGroup.querySelectorAll(".pill").forEach(p => p.classList.remove("active"));
        pill.classList.add("active");
        selectedPresentation = pill.dataset.val;
      });
    });
  }

  // --- Creator Reference Upload Handling ---
  creatorInput.addEventListener("change", (e) => {
    if (e.target.files && e.target.files[0]) {
      setCreatorFile(e.target.files[0]);
    }
  });

  function setCreatorFile(file) {
    creatorFile = file;
    const reader = new FileReader();
    reader.onload = (e) => {
      creatorPreviewImg.src = e.target.result;
      creatorPrompt.classList.add("hidden");
      creatorPreviewBox.classList.remove("hidden");
    };
    reader.readAsDataURL(file);
  }

  removeCreatorBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    creatorFile = null;
    creatorInput.value = "";
    creatorPreviewImg.src = "";
    creatorPreviewBox.classList.add("hidden");
    creatorPrompt.classList.remove("hidden");
  });

  // --- Product Reference(s) Upload Handling ---
  productInput.addEventListener("change", (e) => {
    if (e.target.files && e.target.files.length > 0) {
      for (const file of e.target.files) {
        productFiles.push(file);
      }
      renderProductPreviews();
    }
  });

  function renderProductPreviews() {
    productPreviewGrid.innerHTML = "";
    if (productFiles.length === 0) {
      productPreviewGrid.classList.add("hidden");
      productPrompt.classList.remove("hidden");
      return;
    }

    productPrompt.classList.add("hidden");
    productPreviewGrid.classList.remove("hidden");

    productFiles.forEach((file, index) => {
      const item = document.createElement("div");
      item.className = "multi-preview-item";

      const img = document.createElement("img");
      const reader = new FileReader();
      reader.onload = (e) => { img.src = e.target.result; };
      reader.readAsDataURL(file);

      const removeBtn = document.createElement("button");
      removeBtn.type = "button";
      removeBtn.className = "btn-remove";
      removeBtn.innerHTML = "✕";
      removeBtn.title = "Remove this photo";
      removeBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        productFiles.splice(index, 1);
        renderProductPreviews();
      });

      item.appendChild(img);
      item.appendChild(removeBtn);
      productPreviewGrid.appendChild(item);
    });
  }

  // --- Drag & Drop Decorators ---
  setupDragDrop("creatorDropzone", (files) => {
    if (files.length > 0) setCreatorFile(files[0]);
  });

  setupDragDrop("productDropzone", (files) => {
    if (files.length > 0) {
      for (const file of files) productFiles.push(file);
      renderProductPreviews();
    }
  });

  function setupDragDrop(elemId, onFiles) {
    const el = document.getElementById(elemId);
    ["dragenter", "dragover"].forEach(eventName => {
      el.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        el.classList.add("dragover");
      });
    });
    ["dragleave", "drop"].forEach(eventName => {
      el.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        el.classList.remove("dragover");
      });
    });
    el.addEventListener("drop", (e) => {
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        onFiles(e.dataTransfer.files);
      }
    });
  }

  // --- Tab Switching ---
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.tab).classList.add("active");
    });
  });

  // Helper: Client-side smart image compression (downscale to max 1280px, ~250KB)
  async function compressImage(file, maxDimension = 1280, quality = 0.85) {
    if (!file || !file.type.startsWith("image/")) return file;
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          let { width, height } = img;
          if (width > maxDimension || height > maxDimension) {
            if (width > height) {
              height = Math.round((height * maxDimension) / width);
              width = maxDimension;
            } else {
              width = Math.round((width * maxDimension) / height);
              height = maxDimension;
            }
          }
          const canvas = document.createElement("canvas");
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          ctx.drawImage(img, 0, 0, width, height);
          canvas.toBlob(
            (blob) => {
              if (blob) {
                const compressedFile = new File([blob], file.name.replace(/\.[^/.]+$/, "") + ".jpg", {
                  type: "image/jpeg",
                  lastModified: Date.now()
                });
                resolve(compressedFile);
              } else {
                resolve(file);
              }
            },
            "image/jpeg",
            quality
          );
        };
        img.onerror = () => resolve(file);
        img.src = e.target.result;
      };
      reader.onerror = () => resolve(file);
      reader.readAsDataURL(file);
    });
  }

  // --- Form Submission ---
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const isDemo = demoModeToggle.checked;

    if (!isDemo) {
      if (!creatorFile) {
        showToast("⚠️ Please upload a Creator Reference photo (or enable Demo Mode).");
        return;
      }
      if (productFiles.length === 0) {
        showToast("⚠️ Please upload at least 1 Meesho product photo.");
        return;
      }
    }

    // UI Loading State
    emptyState.classList.add("hidden");
    resultContainer.classList.add("hidden");
    outputActions.classList.add("hidden");
    loadingState.classList.remove("hidden");
    generateBtn.disabled = true;

    // Loading Step Simulation
    simulateLoadingSteps();

    // Compress images before sending to prevent timeouts
    const compressedCreator = creatorFile ? await compressImage(creatorFile) : null;
    const compressedProducts = [];
    for (const p of productFiles) {
      compressedProducts.push(await compressImage(p));
    }

    // Prepare FormData
    const formData = new FormData();
    formData.append("duration", selectedDuration);
    formData.append("language", selectedLanguage);
    formData.append("presentation_mode", selectedPresentation);
    formData.append("category_hint", categoryHint.value);
    formData.append("notes", productNotes.value);
    formData.append("demo_mode", isDemo ? "true" : "false");

    if (compressedCreator) {
      formData.append("creator_image", compressedCreator);
    }
    compressedProducts.forEach(file => {
      formData.append("product_images", file);
    });

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        body: formData
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Generation failed");
      }

      currentMarkdown = data.markdown;
      renderScriptOutput(data.markdown);

      // Display Safe "Only Clothes" Images Gallery
      const crops = data.safe_crop_urls || (data.safe_crop_url ? [data.safe_crop_url] : []);
      if (crops.length > 0 && safeCropGallery) {
        safeCropGallery.innerHTML = "";
        crops.forEach((url, idx) => {
          const item = document.createElement("div");
          item.className = "safe-crop-item";
          item.innerHTML = `
            <div class="safe-crop-thumb">
              <img src="${url}" alt="Clean Clothes ${idx+1}">
            </div>
            <a href="${url}" download="safe_clothes_photo_${idx+1}.jpg" class="btn-download-crop">
              ⬇️ Save #${idx+1}
            </a>
          `;
          safeCropGallery.appendChild(item);
        });
        safeCropCard.classList.remove("hidden");
      } else {
        safeCropCard.classList.add("hidden");
      }

      if (data.notice) {
        showToast(data.notice);
      } else {
        showToast("✨ Script & Google Flow Prompts generated successfully!");
      }

    } catch (err) {
      alert("Error: " + err.message);
      emptyState.classList.remove("hidden");
    } finally {
      loadingState.classList.add("hidden");
      generateBtn.disabled = false;
    }
  });

  function simulateLoadingSteps() {
    const steps = [
      document.getElementById("step1"),
      document.getElementById("step2"),
      document.getElementById("step3"),
      document.getElementById("step4")
    ];
    steps.forEach(s => s.classList.remove("active"));
    steps[0].classList.add("active");

    setTimeout(() => { if (steps[1]) { steps[0].classList.remove("active"); steps[1].classList.add("active"); } }, 2000);
    setTimeout(() => { if (steps[2]) { steps[1].classList.remove("active"); steps[2].classList.add("active"); } }, 4500);
    setTimeout(() => { if (steps[3]) { steps[2].classList.remove("active"); steps[3].classList.add("active"); } }, 7500);
  }

  // --- Render Script Results ---
  function renderScriptOutput(md) {
    rawMarkdownCode.textContent = md;
    
    // Parse Markdown into structured interactive HTML
    interactiveOutput.innerHTML = parseScriptToInteractive(md);

    // Attach copy prompt events
    interactiveOutput.querySelectorAll(".btn-copy-prompt").forEach(btn => {
      btn.addEventListener("click", () => {
        const text = decodeURIComponent(btn.dataset.prompt);
        navigator.clipboard.writeText(text);
        showToast("📋 Google Flow Prompt copied to clipboard!");
      });
    });

    resultContainer.classList.remove("hidden");
    outputActions.classList.remove("hidden");
  }

  function parseScriptToInteractive(md) {
    // If marked is loaded, render rich markdown, with custom cards for scenes and Google Flow blocks
    let html = "";

    // Extract Hook section if present
    const hookMatch = md.match(/### 🪝 Selected Hook[\s\S]*?\*\*Hook Score:\s*([^\*]+)\*\*[\s\S]*?(?:Hook|Spoken Hook)[:\s]*"([^"]+)"/i);
    if (hookMatch) {
      const score = hookMatch[1].trim();
      const hookText = hookMatch[2].trim();
      html += `
        <div class="hook-card">
          <div class="hook-badge-row">
            <span style="font-weight:700; color:var(--accent-pink); font-size:0.85rem;">🪝 SELECTED RETENTION HOOK</span>
            <span class="hook-score">Retention Score: ${score}</span>
          </div>
          <div class="hook-quote">"${hookText}"</div>
          <div class="hook-why">⚡ Engineered for instant 0–3 second pattern interrupt and maximum scroll-stop rate.</div>
        </div>
      `;
    }

    // Convert full markdown using marked.js
    if (typeof marked !== "undefined") {
      let markedHtml = marked.parse(md);

      // Enhance code blocks that contain REFERENCE IMAGE to add a quick copy button
      markedHtml = markedHtml.replace(/<pre><code[^>]*>([\s\S]*?REFERENCE IMAGE[\s\S]*?)<\/code><\/pre>/gi, (match, codeContent) => {
        const cleanPrompt = codeContent
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/&amp;/g, '&');
        const encoded = encodeURIComponent(cleanPrompt);
        return `
          <div class="flow-prompt-box">
            <div class="flow-prompt-header">
              <span class="flow-tag">⚡ GOOGLE FLOW (VEO) VIDEO PROMPT</span>
              <button class="btn-copy-prompt" data-prompt="${encoded}">📋 Copy Prompt</button>
            </div>
            <pre class="flow-prompt-text">${codeContent}</pre>
          </div>
        `;
      });

      html += `<div class="parsed-content">${markedHtml}</div>`;
    } else {
      html += `<pre class="markdown-pre">${escapeHtml(md)}</pre>`;
    }

    return html;
  }

  function escapeHtml(str) {
    return str.replace(/[&<>'"]/g, 
      tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
    );
  }

  // --- Copy All & Download ---
  copyAllBtn.addEventListener("click", () => {
    if (!currentMarkdown) return;
    navigator.clipboard.writeText(currentMarkdown);
    showToast("📋 Entire Script & Flow Prompts copied to clipboard!");
  });

  downloadBtn.addEventListener("click", () => {
    if (!currentMarkdown) return;
    const blob = new Blob([currentMarkdown], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `meesho_video_script_${Date.now()}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast("💾 Script downloaded as .md");
  });

  // --- API Key Modal Logic ---
  apiKeyBtn.addEventListener("click", () => {
    keyModal.classList.remove("hidden");
  });

  [closeKeyModal, cancelKeyModal].forEach(el => {
    el.addEventListener("click", () => {
      keyModal.classList.add("hidden");
    });
  });

  saveKeyBtn.addEventListener("click", async () => {
    const key = modalKeyInput.value.trim();
    if (!key) {
      alert("Please enter a valid Gemini API Key.");
      return;
    }

    try {
      const res = await fetch("/api/save-key", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ api_key: key })
      });
      const data = await res.json();
      if (res.ok) {
        showToast("✅ Gemini API Key saved locally!");
        keyModal.classList.add("hidden");
        modalKeyInput.value = "";
        fetchStatus();
      } else {
        alert(data.error || "Failed to save key");
      }
    } catch (e) {
      alert("Error: " + e.message);
    }
  });

  // --- Toast Function ---
  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.remove("hidden");
    setTimeout(() => {
      toast.classList.add("hidden");
    }, 3500);
  }
});
